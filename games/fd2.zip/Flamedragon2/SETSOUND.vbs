'
' This script made by GLORYPAPA.
' https://glorypapa.com
'
Set WinScriptHost = CreateObject( "WScript.shell" )
WinScriptHost.Run Chr(34) & "FD2\SETSOUND.BAT" & Chr(34), 0
Set WinScriptHost = Nothing